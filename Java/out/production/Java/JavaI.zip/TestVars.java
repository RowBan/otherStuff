public class TestVars {
    public static void main(String[] args) {
        int $mooncirc = 10921;
        double $c = 1.255;
        String $moon = "Circumference of the moon is: " + $mooncirc + " kilometers and light takes " + $c + " seconds to get to earth.";
        System.out.println($moon);
    }
}