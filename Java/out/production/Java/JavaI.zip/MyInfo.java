public class MyInfo {
    static public void main(String[] args) {
        int $age = 32;
        String $name = "Robert Eriksson";
        String $lives = "Bergsjö";
        String $wtc = "för att jag vill lära mig programmering, rent allmänt.";
        System.out.println("Hej, jag heter " + $name + " och är " + $age + " år gammal. Jag bor i " + $lives + " och går den här kursen " + $wtc);
    }
}