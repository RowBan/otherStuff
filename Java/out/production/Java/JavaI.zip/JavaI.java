public class JavaI {
    public static void main(String[] args) {
    System.out.println("Datateknik GR(A), Java I");
    }
}